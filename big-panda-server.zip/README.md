# Development

1. Clone the project with `git clone ..`
2. In the cloned folder install the requirement npm modules `npm install`
3. Start the server locally `npm start` _(it will open the page once it finished initializing)_

**Note:** The server will be restart automatically when the project files is changed (only when started with `npm start`)